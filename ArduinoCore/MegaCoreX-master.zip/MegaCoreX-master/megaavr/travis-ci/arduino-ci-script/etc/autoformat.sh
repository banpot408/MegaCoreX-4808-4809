shfmt -i 2 -w ../arduino-ci-script.sh
